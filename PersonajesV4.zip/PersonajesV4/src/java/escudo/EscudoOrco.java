package escudo;

/**
 * Clase de Escudo(Orco)
 * @author VARGAS
 */
public class EscudoOrco extends EscudoAbstracto {
    public EscudoOrco(){}

    @Override
    public String imagen() {
        return "imagenes/escudoOrco.png";
    }
}
