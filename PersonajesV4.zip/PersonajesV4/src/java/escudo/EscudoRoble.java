package escudo;

/**
 * Clase de Escudo(Enano)
 * @author VARGAS
 */
public class EscudoRoble extends EscudoAbstracto {
    public EscudoRoble(){}

    @Override
    public String imagen() {
        return "imagenes/escudoEnano.png";
    }
}
