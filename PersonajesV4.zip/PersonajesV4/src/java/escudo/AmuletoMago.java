package escudo;

/**
 * Clase de Amuleto del Mago
 * @author VARGAS
 */
public class AmuletoMago extends EscudoAbstracto {
    public AmuletoMago(){}

    @Override
    public String imagen() {
        return "imagenes/escudoMago.png";
    }
}
