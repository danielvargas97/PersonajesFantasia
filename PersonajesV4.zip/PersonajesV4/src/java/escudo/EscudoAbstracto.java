package escudo;

import personaje.Parte;


/**
 *Clase de escudo abstracto
 * @author Invitado
 */
public abstract class EscudoAbstracto extends Parte {
    
    /*
    Metodo que devuelve la ruta de la imagen de cada tipo
    de escudo
    */
    public abstract String imagen();
}
