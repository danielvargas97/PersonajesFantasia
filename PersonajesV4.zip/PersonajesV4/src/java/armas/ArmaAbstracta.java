package armas;

import personaje.Parte;

/**
 *
 * @author Invitado
 */
public abstract class ArmaAbstracta extends Parte{
    /**
     * Devuelve la ruta de la imagen del arma
     * @return ruta de la imagen del arma del personaje
     */
    @Override
    public abstract String imagen();
    
}
