package personaje;

/**
 *
 * @author VARGAS
 */
public abstract class Parte {
    protected int posicionX;
    protected int posicionY;
    protected String nombre;
    
    public abstract String imagen();

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
