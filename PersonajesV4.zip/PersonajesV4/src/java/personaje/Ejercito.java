package personaje;

import java.util.ArrayList;

/**
 *
 * @author Estudiantes
 */
public class Ejercito extends Componente {
    private ArrayList<Componente> poblacion;
    public Ejercito(){
        super();
        poblacion = new ArrayList<>();
    }
    
    
    @Override
    public void moverIzquierda() {
        
        for(Componente c: poblacion){
            c.moverIzquierda();
        }    
    }
    
    @Override
    public String mostrarDatos(){
        for(Componente p:poblacion){
            p.mostrarDatos();
        }
        return poblacion.get(0).mostrarDatos();
    }
    
    @Override
    public void agregar(Componente comp) {
        poblacion.add(comp);
    }

    @Override
    public void remover(Componente comp) {
        poblacion.remove(comp);
    }

    @Override
    public Componente obtenerParte(int numeroHijo) {
        return poblacion.get(numeroHijo);
    }  
    
}
