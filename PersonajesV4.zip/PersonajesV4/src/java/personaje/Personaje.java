package personaje;

import armas.ArmaAbstracta;
import cuerpo.Cuerpo;
import escudo.EscudoAbstracto;
import montura.Montura;
/**
 *
 * @author Estudiantes
 */
public abstract class Personaje extends Componente implements Cloneable {
    protected int posicionX;
    protected int posicionY;
    
    protected int vida;
            
            
    protected Cuerpo miCuerpo;
    protected Montura miMontura;
    protected EscudoAbstracto miEscudo;
    protected ArmaAbstracta miArma;
    
    
    /**
     * Da una pequeña descripcion del Personaje
     * @return tipo del Personaje
     */
    @Override
    public abstract String toString();
    
    /**
     * Realiza una copia de un personaje
     * @return copia del Personaje
     */
    public abstract Personaje clonarPersonaje();
    
    
    public Cuerpo getMiCuerpo() {
        return miCuerpo;
    }

    
    public String getImgRuta(Parte miPieza){
        return miPieza.imagen();
    }
    @Override
    public void moverIzquierda(){
        System.out.println("Moviendo a la izquierda");
        this.posicionX-=1;
    
    }  
    
    @Override
    public String mostrarDatos(){
        String data = this.toString()+" Posición:("+this.posicionX+","+this.posicionY+")";
        return data;
    }
    
    @Override
    public void agregar(Componente comp) {
        System.out.println("No se puede agregar");
    }

    @Override
    public void remover(Componente comp) {
        System.out.println("No se puede remover");
    }
    
    /**
     *
     * @param numHijo
     * @return
     */
    @Override
    public Componente obtenerParte(int numHijo){
        Componente c = null;
        return c;
    }
  
    public void setMiCuerpo(Cuerpo miCuerpo) {
        this.miCuerpo = miCuerpo;
    }

    public Montura getMiMontura() {
        return miMontura;
    }

    public void setMiMontura(Montura miMontura) {
        this.miMontura = miMontura;
    }

    public EscudoAbstracto getMiEscudo() {
        return miEscudo;
    }

    public void setMiEscudo(EscudoAbstracto miEscudo) {
        this.miEscudo = miEscudo;
    }

    public ArmaAbstracta getMiArma() {
        return miArma;
    }

    public void setMiArma(ArmaAbstracta miArma) {
        this.miArma = miArma;
    }

    public int getPosicionX() {
        return posicionX;
    }

    public void setPosicionX(int posicionX) {
        this.posicionX = posicionX;
    }

    public int getPosicionY() {
        return posicionY;
    }

    public void setPosicionY(int posicionY) {
        this.posicionY = posicionY;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }
}
