package personaje;
/**
 *
 * @author Estudiantes
 */
public abstract class Componente {
    
    public abstract String mostrarDatos();
    public abstract void moverIzquierda();
    public abstract void agregar(Componente comp);
    public abstract void remover(Componente comp);
    public abstract Componente obtenerParte(int numeroHijo);
}
