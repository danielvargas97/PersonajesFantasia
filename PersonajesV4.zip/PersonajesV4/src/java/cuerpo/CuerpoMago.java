package cuerpo;

/**
 * Clase de Cuerpo de Mago
 * @author VARGAS
 */
public class CuerpoMago extends Cuerpo {

    @Override
    public String imagen() {
        return "imagenes/cuerpoMago.png";
    }
    
}
