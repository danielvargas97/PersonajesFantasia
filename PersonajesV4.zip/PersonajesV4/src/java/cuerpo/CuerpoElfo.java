package cuerpo;

/**
 * Clase de Cuerpo de Elfo
 * @author VARGAS
 */
public class CuerpoElfo extends Cuerpo {
    public CuerpoElfo(){
        super();
    }

    @Override
    public String imagen() {
        return "imagenes/cuerpoElfo.png";
    }
}
