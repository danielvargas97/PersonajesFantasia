package cuerpo;

/**
 * Clase de Cuerpo de Orco
 * @author VARGAS
 */
public class CuerpoOrco extends Cuerpo {

    @Override
    public String imagen() {
        return "imagenes/cuerpoOrco.png";
    }
    
}
