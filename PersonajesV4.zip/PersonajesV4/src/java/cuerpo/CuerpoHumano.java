
package cuerpo;

/**
 * Clase de Cuerpo de Humano
 * @author VARGAS
 */
public class CuerpoHumano extends Cuerpo {
    public CuerpoHumano(){
        super();
    }

    @Override
    public String imagen() {
        return "imagenes/cuerpoHumano.png";
    }
}
