package cuerpo;

/**
 * Clase de Cuerpo de Enano
 * @author VARGAS
 */
public class CuerpoEnano extends Cuerpo {

    @Override
    public String imagen() {
        return "imagenes/cuerpoEnano.png";
    }
    
}
