package logica;

import armas.ArmaAbstracta;
import constructores.*;
import cuerpo.Cuerpo;
import escudo.EscudoAbstracto;
import fabricas.*;
import montura.Montura;
import personaje.Componente;
import personaje.Ejercito;
import personaje.Personaje;

/**
 *
 * @author Invitado
 */
public class Cliente {
    
    private FabricaAbstracta fabAbs;
    private EscudoAbstracto escAbs;
    private ArmaAbstracta armAbs;
    private Cuerpo cuerpoAbs;
    private Montura monturaAbs;
    private Director dic;
    private Constructor cons;
    private Componente miComp;
    
    
    
    public Cliente() {
        miComp = new Ejercito();
    }
    
    public void agregarPersonaje(Componente comp){
        miComp.agregar(comp);         
    }
    /*
    Metodo que ejecuta las acciones para el ejercito
    */
    public void ejecucion(){
        miComp.moverIzquierda();
    }

    public Componente getMiComp() {
        return miComp;
    }

    public void setMiComp(Componente miComp) {
        this.miComp = miComp;
    }
       
    /*
    Metodo que crea el personaje segun la elección hecha en html y 
    gestionada por el servlet
    */
    /*
    public void personaje(String tipo){
        if(tipo.equalsIgnoreCase("Humano")){
            fabAbs = FabricaHumano.getFabricaHumanos();
        }else if(tipo.equalsIgnoreCase("Elfo")){
            fabAbs = FabricaElfo.getFabricaElfos();
        }else if(tipo.equalsIgnoreCase("Enano")){
            fabAbs = FabricaEnanos.getFabricaEnanos();
        }else if(tipo.equalsIgnoreCase("Mago")){
            fabAbs = FabricaMagos.getFabricaMagos();
        }else if(tipo.equalsIgnoreCase("Orco")){
            fabAbs = FabricaOrcos.getFabricaOrcos();
        }
    }*/
    
    
    /**
     * Determina el tipo de constructor a utilizar para crear Personaje
     * @param tipo el tipo de personaje a crear (Ej:Orco)
     */
    public void seleccionarConstructor(String tipo){
        if(tipo.equalsIgnoreCase("Humano")){
            cons= new ConstructorHumano();   
        }else if(tipo.equalsIgnoreCase("Elfo")){
            cons= new ConstructorElfo();   
        }else if(tipo.equalsIgnoreCase("Enano")){
            cons= new ConstructorEnano();   
        }else if(tipo.equalsIgnoreCase("Mago")){
            cons= new ConstructorMago();   
        }else if(tipo.equalsIgnoreCase("Orco")){
            cons= new ConstructorOrco();   
        }
    }
    
    /**
     * Crea un personaje
     * @param constructor encargado de armar las partes de un tipo de personaje
     * @return Personaje con todos sus componentes
     */
    public Personaje crear(Constructor constructor){
        dic = new Director(constructor);
        dic.construirPersonaje();
        return dic.getPersonaje();
    }
    
    /**
     * Crea una copia de algun tipo de Personaje
     * @param tipo Es el tipo de personaje a copiar (Ej:Mago)
     * @return Copia del personaje
     */
    public Personaje crearCopia(String tipo){
        seleccionarConstructor(tipo);
        Personaje p = crear(cons);
        return p.clonarPersonaje();
        
    }
    
    /*
    Metodo que crea el arma dependiendo del personaje elegido anteriormente
    y retorna un string con la url de la imagen
    */
    public String arma(){
        armAbs=fabAbs.crearArma();
        return armAbs.imagen();
    }
    
    /*
    Metodo que crea el cuerpo dependiendo del personaje elegido anteriormente
    y retorna un string con la url de la imagen
    */
    public String cuerpo(){
        cuerpoAbs=fabAbs.crearCuerpo();
        return cuerpoAbs.imagen();
    }
    
    /*
    Metodo que crea el escudo dependiendo del personaje elegido y retorna
    un string con la url de la imagen
    */
    public String escudo(){
        escAbs = fabAbs.crearEscudo();
        return escAbs.imagen();
    }
    
    /*
    Metodo que crea la montura dependiendo del personaje elegido y retorna
    un string con la url de la imagen
    */
    public String montura(){
        monturaAbs = fabAbs.crearMontura();
        return monturaAbs.imagen();
    }

    public Constructor getConstructor() {
        return cons;
    }

    
    //Componente c = new Ejercito();
    //c.
    
    /*
    public void accion(){
        miComp.mostrarSaludoBatalla();
    }
    */
    
}
