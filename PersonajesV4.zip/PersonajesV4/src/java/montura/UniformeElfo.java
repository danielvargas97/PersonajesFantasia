
package montura;

/**
 * Clase de Montura(Elfo)
 * @author VARGAS
 */
public class UniformeElfo extends Montura {
    public UniformeElfo(){
    }

    @Override
    public String imagen() {
        return "imagenes/uniformeElfo.png";
    }
}
