package montura;

import personaje.Parte;



/**
 *Clase de Montura Abstracta
 * @author VARGAS
 */
public abstract class Montura extends Parte {

    public abstract String imagen();
    
}
