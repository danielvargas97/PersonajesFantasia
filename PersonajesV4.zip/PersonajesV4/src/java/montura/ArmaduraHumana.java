package montura;

/**
 * Clase de Montura(Humano)
 * @author VARGAS
 */
public class ArmaduraHumana extends Montura {
    public ArmaduraHumana(){}

    @Override
    public String imagen() {
        return "imagenes/armaduraHumana.png";
    }
}
