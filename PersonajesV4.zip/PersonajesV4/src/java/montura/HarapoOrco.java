
package montura;

/**
 * Clase de Montura(Orco)
 * @author VARGAS
 */
public class HarapoOrco extends Montura {
    
    public HarapoOrco(){
    }

    @Override
    public String imagen() {
        return "imagenes/harapoOrco.png";
    }
    
}
