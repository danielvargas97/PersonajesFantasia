
import logica.Cliente;
import personaje.Componente;
import personaje.Ejercito;
import personaje.Personaje;

/**
 *
 * @author VARGAS
 */
public class Test {
    public static void main(String args[]){
        Cliente cli = new Cliente();
        cli.seleccionarConstructor("Mago");
        Personaje p = cli.crear(cli.getConstructor());
        Personaje q = p.clonarPersonaje();
   
        Componente c = new Ejercito();
        c.agregar(p);
        c.agregar(q);
        c.agregar(q);
        c.agregar(q);
        c.agregar(q);
        c.agregar(q);
        c.agregar(q);
        c.agregar(q);
        
        
        Componente d = p.clonarPersonaje();
        
        c.agregar(d);
        
        Componente e = new Ejercito();
        
        e.agregar(c);
        e.moverIzquierda();
        
    }
}
