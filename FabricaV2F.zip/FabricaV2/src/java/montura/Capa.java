package montura;

/**
 * Clase de Montura(Mago)
 * @author VARGAS
 */
public class Capa extends Montura {
    public Capa(){}

    @Override
    public String imagen() {
        return "imagenes/capa.png";
    }
    
    
}
