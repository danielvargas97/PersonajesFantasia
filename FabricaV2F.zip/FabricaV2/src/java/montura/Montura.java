package montura;

/**
 *Clase de Montura Abstracta
 * @author VARGAS
 */
public abstract class Montura {

    public abstract String imagen();
    
}
