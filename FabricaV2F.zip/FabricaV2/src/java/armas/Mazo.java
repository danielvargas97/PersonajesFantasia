
package armas;

/**
 * Clase de Mazo(Enanos)
 * @author VARGAS
 */
public class Mazo extends ArmaAbstracta {
    public Mazo(){}

    @Override
    public String imagen() {
        return "imagenes/mazo.png";
    }
}
