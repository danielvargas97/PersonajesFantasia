
package armas;

/**
 * Clase de Martillo(Orcos)
 * @author VARGAS
 */
public class Martillo extends ArmaAbstracta {
    public Martillo(){
    
    }

    @Override
    public String imagen() {
        return "imagenes/martillo.png";
    }
}
