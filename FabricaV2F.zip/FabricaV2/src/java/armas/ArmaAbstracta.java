/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package armas;


/**
 *
 * @author Invitado
 */
public abstract class ArmaAbstracta {
    /**
     * Devuelve la ruta de la imagen del arma
     * @return ruta de la imagen del arma del personaje
     */
    public abstract String imagen();
    
}
