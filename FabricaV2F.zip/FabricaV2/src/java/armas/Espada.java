package armas;


/**
 * Clase de Espada(Humanos)
 * @author Invitado
 */
public class Espada extends ArmaAbstracta {

    public Espada() {
        
    }

    @Override
    public String imagen() {
        return "imagenes/espada.png";
    }
    
}
