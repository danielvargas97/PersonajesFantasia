package armas;

import java.awt.Image;

/**
 * Clase de Hacha(Elfos)
 * @author Invitado
 */
public class Hacha extends ArmaAbstracta{

    public Hacha() {
        
    }

    @Override
    public String imagen() {
        return "imagenes/hacha.png";
    }
 
}
