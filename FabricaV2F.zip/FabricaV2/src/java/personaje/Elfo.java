package personaje;

/**
 *
 * @author Estudiantes
 */
public class Elfo extends Personaje {

    @Override
    public String toString() {
        return "elfo";
    }
    
}
