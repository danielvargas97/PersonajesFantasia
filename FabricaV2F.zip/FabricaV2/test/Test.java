
import constructores.ConstructorElfo;
import constructores.ConstructorEnano;
import constructores.ConstructorHumano;
import constructores.ConstructorMago;
import constructores.ConstructorOrco;
import constructores.Director;
import personaje.Personaje;


/**
 *
 * @author VARGAS
 */
public class Test {
    public static void main(String args[]){
        Director mc = new Director();
        mc.setMiConstructor(new ConstructorEnano());
        
        mc.construirPersonaje();
        
        Personaje p = mc.getPersonaje();
        
        System.out.println(p.toString());

        
    }
}
