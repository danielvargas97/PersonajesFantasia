package armas;

/**
 * Clase de Baston(Magos)
 * @author VARGAS
 */
public class Baston extends ArmaAbstracta {
    public Baston(){}

    @Override
    public String imagen() {
        return "imagenes/baston.png";
    }
}
