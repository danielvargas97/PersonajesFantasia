package armas;

import personaje.PiezaPersonaje;


/**
 *
 * @author Invitado
 */
public abstract class ArmaAbstracta implements PiezaPersonaje{
    /**
     * Devuelve la ruta de la imagen del arma
     * @return ruta de la imagen del arma del personaje
     */
    @Override
    public abstract String imagen();
    
}
