package personaje;

/**
 *
 * @author VARGAS
 */
public interface PiezaPersonaje {
    public String imagen();
}
