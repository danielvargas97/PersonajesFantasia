package montura;

import personaje.PiezaPersonaje;

/**
 *Clase de Montura Abstracta
 * @author VARGAS
 */
public abstract class Montura implements PiezaPersonaje {

    public abstract String imagen();
    
}
