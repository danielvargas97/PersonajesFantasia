package montura;

/**
 * Clase de Montura(Enano)
 * @author VARGAS
 */
public class CamisaEnano extends Montura {
    public CamisaEnano(){}

    @Override
    public String imagen() {
        return "imagenes/camisaEnano.png";
    }
    
    
}
