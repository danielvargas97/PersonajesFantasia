package escudo;

import personaje.PiezaPersonaje;


/**
 *Clase de escudo abstracto
 * @author Invitado
 */
public abstract class EscudoAbstracto implements PiezaPersonaje {
    
    /*
    Metodo que devuelve la ruta de la imagen de cada tipo
    de escudo
    */
    public abstract String imagen();
}
