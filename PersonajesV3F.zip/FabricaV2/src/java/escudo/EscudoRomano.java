package escudo;

/**
 * Clase de Escudo(Humano)
 * @author Invitado
 */
public class EscudoRomano extends EscudoAbstracto{

    public EscudoRomano() {
    }

    @Override
    public String imagen() {
        return "imagenes/escudoRomano.png";
    }

}
