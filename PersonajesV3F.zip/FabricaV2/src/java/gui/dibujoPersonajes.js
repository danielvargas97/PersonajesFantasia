//function dibujarPersonaje(ff){
//    var
  //  ff.drawImage
//};
